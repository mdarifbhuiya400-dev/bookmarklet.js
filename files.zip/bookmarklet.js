/*
  Bookmarklet Script for Leaderboard, Account Switch & Profile Features
  Author: @code_seller14 (Telegram)
  Usage: Copy the entire code and use as a bookmarklet in your browser.
*/

// Leaderboard name and initial capital
let lname = "Hachib Hasan";
let iblafp = 10000;

// Change the URL to target page
window.history.pushState({}, "", "https://qxbroker.com/en/trade");

// Switch live/demo account by text and set active state
document.getElementsByClassName("usermenu__info-name")[0].innerHTML = "LIVE";
let elm1 = document.getElementsByClassName("sidebar__button")[1];
elm1.setAttribute("id", "real");
let elm2 = document.getElementsByClassName("sidebar__button")[2];
elm2.setAttribute("id", "demo");
document.getElementById("real").classList.toggle("active");
document.getElementById("demo").classList.toggle("active");

// Dynamic profile icon based on balance
setInterval(function () {
    let blc = document.getElementsByClassName("usermenu__info-balance")[0].innerHTML;
    blc = blc.replaceAll(",", "").replaceAll("$", "").replaceAll(".", "");
    blc = parseInt(blc.substring(0, blc.length - 2));
    let icoin;
    if (blc < 5000) {
        icoin = '<svg class="icon-profile-level-standart"><use xlink:href="/profile/images/spritemap.svg#icon-profile-level-standart"></use></svg>';
    } else if (blc >= 5000 && blc < 10000) {
        icoin = '<svg class="icon-profile-level-standart"><use xlink:href="/profile/images/spritemap.svg#icon-profile-level-pro"></use></svg>';
    } else if (blc >= 10000) {
        icoin = '<svg class="icon-profile-level-standart"><use xlink:href="/profile/images/spritemap.svg#icon-profile-level-vip"></use></svg>';
    }
    document.getElementsByClassName("usermenu__info-levels")[0].innerHTML = icoin;
}, 10);

// Dynamic dropdown info
setInterval(function () {
    let blc = document.getElementsByClassName("usermenu__info-balance")[0].innerHTML;
    blc = blc.replaceAll(",", "").replaceAll("$", "").replaceAll(".", "");
    blc = parseInt(blc.substring(0, blc.length - 2));
    let icoin, levelName, levelProfit;
    if (blc < 5000) {
        levelProfit = '+0% profit';
        levelName = "STANDARD:";
        icoin = '<svg class="icon-profile-level-standart"><use xlink:href="/profile/images/spritemap.svg#icon-profile-level-standart"></use></svg>';
    } else if (blc >= 5000 && blc < 10000) {
        levelProfit = '+2% profit';
        levelName = "PRO:";
        icoin = '<svg class="icon-profile-level-standart"><use xlink:href="/profile/images/spritemap.svg#icon-profile-level-pro"></use></svg>';
    } else if (blc >= 10000) {
        levelProfit = '+4% profit';
        levelName = "VIP:";
        icoin = '<svg class="icon-profile-level-standart"><use xlink:href="/profile/images/spritemap.svg#icon-profile-level-vip"></use></svg>';
    }
    let menu = document.getElementsByClassName("usermenu__dropdown")[0];
    if (menu != null) {
        document.getElementsByClassName("usermenu__level-icon")[0].innerHTML = icoin;
        document.getElementsByClassName("usermenu__level-name")[0].innerHTML = levelName;
        document.getElementsByClassName("usermenu__level-profit")[0].innerHTML = levelProfit;
        document.getElementsByClassName("usermenu__select-balance")[0].innerHTML = document.getElementsByClassName("usermenu__info-balance")[0].innerHTML;
        document.getElementsByClassName("usermenu__select-balance")[1].innerHTML = "$10,000.00";
        let real1 = document.getElementsByClassName("usermenu__select-item--radio")[0];
        real1.setAttribute("id", "real1");
        let demo1 = document.getElementsByClassName("usermenu__select-item--radio")[1];
        demo1.setAttribute("id", "demo1");
        let real2 = document.getElementById("real1");
        real2.classList.add("active");
        let demo2 = document.getElementById("demo1");
        demo2.classList.remove("active");
    }
}, 10);

// Leaderboard and position logic
setInterval(function () {
    var leaderboard = document.getElementsByClassName("app--sidepanel-open")[0];
    if (leaderboard != null) {
        document.getElementsByClassName("position__loading")[0].style.background = "#0faf59";
        document.getElementsByClassName("position__loading")[0].style.height = "2px";
        let lblc = document.getElementsByClassName("usermenu__info-balance")[0].innerHTML;
        lblc = lblc.replaceAll(",", "").replaceAll("$", "").replaceAll(".", "");
        lblc = parseInt(lblc);
        lprofit = lblc - iblafp;
        lprofit = lprofit.toString();
        if (lprofit == 0) {
            lprofit = "$0.00";
        } else if (lprofit.length == 3) {
            lprofit = "$" + lprofit.slice(0, 1) + "." + lprofit.slice(1, 3);
        } else if (lprofit.length == 4) {
            lprofit = "$" + lprofit.slice(0, 2) + "." + lprofit.slice(2, 4);
        } else if (lprofit.length == 5) {
            lprofit = "$" + lprofit.slice(0, 3) + "." + lprofit.slice(3, 5);
        } else if (lprofit.length == 6) {
            lprofit = "$" + lprofit.slice(0, 1) + "," + lprofit.slice(1, 4) + "." + lprofit.slice(4, 6);
        } else if (lprofit.length == 7) {
            lprofit = "$" + lprofit.slice(0, 2) + "," + lprofit.slice(2, 5) + "." + lprofit.slice(5, 7);
        }
        document.getElementsByClassName("position__header-money --green")[0].innerHTML = lprofit;
        // For brevity, top 20 calculation code omitted. Add as needed from your original!
    }
}, 1000);

/*
  How to use as Bookmarklet:
  - Minify this file (or use as-is for development).
  - Wrap with `javascript:(function(){ ... })();` for bookmarklet.
  - Add to browser bookmark's URL/location.
*/

/*
  Script Coded By @code_seller14 << -- Telegram
*/